    <div class="page-footer">

            <div class="page-footer-inner"> 2019 &copy; Ebosreputation
                <a target="_blank" href="https://ebos-sg.com/">EBOS SG</a> &nbsp;|&nbsp;
                <a href="http://prokakis.com" title="Prokakis" target="_blank">Prokakis</a>
                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div>
            </div>
            <!-- END FOOTER -->
            <!-- BEGIN QUICK NAV -->


            <div class="quick-nav-overlay"></div>
    </div>
