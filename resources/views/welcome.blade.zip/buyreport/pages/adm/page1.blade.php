<div id="watermark">
    <em>PROKAKIS</em>
</div>
<div class="card">
<div class="card-body ">

<div class="row p-2">
    &#160;
</div>

<div class="row p-0">
    <div class="col-md-12 text-center">
        This report prepared by Prokakis for Inquiry on:
    </div>
</div>

<div class="row p-1">
    <div class="col-md-12 text-center">
        <p  class="h1 heading1">{{ $data['COMP_NAME'] }}</p>
        <small class="h6">REGISTRATION NUMBER: {{ $data['COMP_REGISTRATION_NUMBER'] }}</small>
    </div>
</div>

<div class="row p-1">
    <hr class="report-line">
</div>

<div class="row p-3">
    <div class="gray-box">
        <div class="row">
            <div class="col-md-12 text-center">
                <u class="h4">Adverse Media</u>
            </div>
        </div>
      
    </div>
</div>
<div class="row p-5">
    &#160;
</div>
<div class="row p-5">
    &#160;
</div>
<div class="row p-5">
    &#160;
</div>
<div class="row p-0">
     <div class="col-md-12" style="text-align: center; line-height: 0">
        <span>All Rights Reserved &#169; <?php echo date("Y");?> </span><br>
        <span>PROKAKIS PTE LTD</span>
    </div>
</div>

<div class="row p-2">
    &#160;
</div>

<div class="row p-1">
    <div class="col-md-12 text-right">
        PRESENTED BY: PROKAKIS
        <br>
        GENERATED ON: <?php echo date('Y-m-d'); ?>
    </div>
</div>
{{--         <div class="row p-5 page-break">
    <div class="col-md-12">
        @include('buyreport.disclaimer')
    </div>
</div> --}}
</div>
</div>