<footer>
<div class="pageNum-div  p-0"><small >Page | <span class="pagenum "></span></small></div>
<div class="footer-text">
{{-- <p class="foot-content "><small> {!! $footer_content !!}</small></p> --}}
	
<p class="foot-content "><small> DISCLAIMER: THIS REPORT MAY NOT BE REPRODUCED IN WHOLE OR IN PART IN ANY FORM OR MANNER WHATSOEVER. This report is forwarded to the User in strict confidence for use by the User as one factor in connection with credit and other business decisions. The report contains information compiled from information which ProKakis does not control and which has not been verified unless indicated in this report. ProKakis therefore cannot accept responsibility for the accuracy, completeness or timeliness of the contents of the report. Prokakis disclaims all liability for any loss or damage arising out of or in anyway related to the contents of this report</small></p>
<p class="text-center foot-copy "><small>&#169; ProKakis <?php echo date("Y");?></small></p>
</div>
</footer>