<footer>
<div class="pageNum-div text-muted text-right p-0"><small >Page | <span class="pagenum "></span></small></div>

<p class="foot-content "><small> STRICTLY CONFIDENTIAL </small></p>
<p class="text-center foot-copy "><small>&#169; ProKakis <?php echo date("Y");?></small></p>
</footer>