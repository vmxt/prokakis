<header>
	<img src="https://app-prokakis.com/public/img-resources/ProKakisNewLogo.png" title="Prokakis" alt="Prokakis" id="logo" width="150px">
</header>